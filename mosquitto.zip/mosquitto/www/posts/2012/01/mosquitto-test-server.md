<!--
.. title: Mosquitto Test Server
.. slug: mosquitto-test-server
.. date: 2012-01-06 21:43:07
.. tags: Support,Testing
.. category:
.. link:
.. description:
.. type: text
-->

A publicly accessible Mosquitto server is now available to use. Details are at
[test.mosquitto.org]

[test.mosquitto.org]: http:/test.mosquitto.org/
