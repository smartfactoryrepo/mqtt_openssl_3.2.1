<!--
.. title: Bugfix coming soon...
.. slug: bugfix-coming-soon
.. date: 2012-08-15 11:13:40
.. tags: Releases,Testing
.. category:
.. link:
.. description:
.. type: text
-->

A few bugs have been identified with the 1.0 release; thanks to everyone who
has got in touch about it. They're mostly documentation/build script mistakes
(see [ChangeLog.txt]), but there is a Python bug that makes it worthwhile
making a quick bugfix release.

I intend to make the release this evening (in around 8 hours from this post),
so if you have anything you think needs fixing please try and get in touch
before then.

[ChangeLog.txt]: /ChangeLog.txt
