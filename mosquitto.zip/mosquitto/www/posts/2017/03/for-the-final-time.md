<!--
.. title: For the final time...
.. slug: for-the-final-time
.. date: 2017-03-09 19:09:59
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
.. author: Roger
-->

This guy arrived on Tuesday, two weeks early and weighing 9lb 6oz / 4.26kg.
Apologies if I'm a bit out of touch for a while.

[![baby picture](/blog/uploads/2017/03/img_20170308_155049248_33196894011_o-300x169.jpg "baby picture")](/blog/uploads/2017/03/img_20170308_155049248_33196894011_o.jpg)
