<!--
.. title: MQTT Power Usage on Android
.. slug: mqtt-power-usage-on-android
.. date: 2011-10-16 20:36:03
.. tags: Mobile
.. category:
.. link:
.. description:
.. type: text
-->

Stephen Nicholas has carried out some power usage analysis of MQTT on Android.
Details are at <http://stephendnicholas.com/archives/219> and the conclusion is
that it doesn't use much power.
