<!--
.. title: Mosquitto on Maemo
.. slug: mosquitto-on-maemo
.. date: 2011-02-13 22:06:04
.. tags: Mobile,Packaging
.. category:
.. link:
.. description:
.. type: text
-->

Yuvraaj Kelkar got in touch to say he's packaged up mosquitto and the client
libraries for Maemo. If you want to use MQTT on your Maemo device then take a
look at the details on <http://talk.maemo.org/showthread.php?t=69604>

Thanks Yuvraaj!
