<!--
.. title: Lightweight Messaging and Linux
.. slug: lightweight-messaging-and-linux
.. date: 2011-02-07 11:40:36
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

Andy Piper was at [Linux Conf Australia] this year and gave a talk on MQTT.

His blog post Lightweight Messaging and Linux] gives a few details and has a
link to the slides. The video can be seen at
<http://linuxconfau.blip.tv/file/4729456/>

[Linux Conf Australia]: http://linux.conf.au/
[Lightweight Messaging and Linux]: http://andypiper.co.uk/2011/01/28/lightweight-messaging-and-linux/
