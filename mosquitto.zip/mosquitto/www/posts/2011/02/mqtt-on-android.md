<!--
.. title: MQTT on Android
.. slug: mqtt-on-android
.. date: 2011-02-01 15:19:37
.. tags: Mobile
.. category:
.. link:
.. description:
.. type: text
-->

Dale Lane has written an enormous blog post [Using MQTT in Android Mobile
Applications in which he talks about a lot of the points you are likely to want
to consider if you're writing MQTT applications for Android. There's lots of
useful information and he even includes a complete source code
implementation.

[Using MQTT in Android Mobile Applications]: http://dalelane.co.uk/blog/?p=1599
