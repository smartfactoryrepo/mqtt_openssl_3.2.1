<!--
.. title: New Linux repositories
.. slug: new-linux-repositories
.. date: 2011-11-11 11:20:41
.. tags: Packaging
.. category:
.. link:
.. description:
.. type: text
-->

I've just added some more Linux repositories to the download page for Fedora 16
and SLE 10, 11 and 11 SP1.

Note that mosquitto-python isn't available on SLE 10.

See the [download page](/download).
