<!--
.. title: API documentation
.. slug: api-documentation
.. date: 2011-03-08 23:36:16
.. tags: Documentation
.. category:
.. link:
.. description:
.. type: text
-->

I've rewritten the API documentation for the C library using the [NaturalDocs]
format. This covers the whole C library and so should give enough information
for anybody using the C++ or Python wrappers as well.

The documentation generated from mosquitto.h is available at
<http://mosquitto.org/api/>

[NaturalDocs]: http://www.naturaldocs.org/
