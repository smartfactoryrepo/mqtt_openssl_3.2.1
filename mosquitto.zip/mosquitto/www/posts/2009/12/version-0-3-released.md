<!--
.. title: Version 0.3 released
.. slug: version-0-3-released
.. date: 2009-12-17 10:52:55
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

 * Added logging support.
 * Now restarts much more quickly even when the network socket was in use.
 * Can now be configured to run on multiple network ports and restricted to
   specific network addresses.
 * Added host access control in the form of tcp-wrappers support.

See the [change log](/ChangeLog.txt) for full details.

Wild card support in topics is coming in the next version.
