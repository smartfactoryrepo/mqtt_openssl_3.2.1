<!--
.. title: Version 0.4.2 released
.. slug: version-0-4-2-released
.. date: 2010-02-06 14:50:27
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

 * Fix segfault on client connect with invalid protocol name/version.

Get it at the [download page].

[download page]: /download
