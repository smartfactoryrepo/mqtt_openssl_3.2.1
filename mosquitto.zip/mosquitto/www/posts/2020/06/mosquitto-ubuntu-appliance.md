<!--
.. title: Mosquitto now an Ubuntu Appliance
.. slug: mosquitto-now-an-ubuntu-appliance
.. date: 2020-06-16 16:01:13 UTC+01:00
.. tags:
.. category: news
.. link:
.. description:
.. type: text
-->

Ubuntu has just announced their new [Ubuntu Appliance] initiative, which provides self contained images for a number of different applications, for use on a Raspberry Pi or PC. These are full Ubuntu derivatives that use snap packages, so will keep up to date with the latest releases.

There are five different applications in the first set of appliances, and Mosquitto is one of them.

Read more at the [Ubuntu blog].

[Ubuntu Appliance]: http://ubuntu.com/appliance
[Ubuntu blog]: https://ubuntu.com/blog/the-ubuntu-appliance-portfolio
