<!--
.. title: Logo contest - results for shortlisting
.. slug: logo-contest-results-for-shortlisting
.. date: 2016-03-23 16:21:24
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

The first round of the logo contest has closed and we now need to shortlist 6
designers. A selection of 20 logos have been chosen out of the 100 entrants and
you are invited to vote on them and make comments. If you like a particular
logo but not the colour, or like an idea behind the logo but not another
element then please say so.

The links for voting (please do look at them all) are:

<https://en.99designs.fr/logo-design/vote-d8v9u9>
<https://en.99designs.fr/logo-design/vote-xlduhg>
<https://99designs.fr/logo-design/vote-n4ynig>
