<!--
.. title: Logo contest
.. slug: logo-contest
.. date: 2016-03-18 11:42:14
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

We have initiated a paid contest to create a new logo for the Mosquitto
project.

If you have graphics design skills or know someone who has,  please head over
to the link below to see the design brief and submit your idea.

<http://en.99designs.de/logo-design/contests/create-logo-eclipse-mosquitto-open-source-server-internet-605670/brief>
